﻿namespace P_SEF1138122_LC1088821
{
    partial class Pelea
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Pelea));
            this.Regresar = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Deck1J2 = new System.Windows.Forms.Label();
            this.S1J2 = new System.Windows.Forms.Label();
            this.Def1J2 = new System.Windows.Forms.Label();
            this.A1J2 = new System.Windows.Forms.Label();
            this.V1J2 = new System.Windows.Forms.Label();
            this.D1j2 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Deck1J1 = new System.Windows.Forms.Label();
            this.S1J1 = new System.Windows.Forms.Label();
            this.Def1J1 = new System.Windows.Forms.Label();
            this.A1J1 = new System.Windows.Forms.Label();
            this.V1J1 = new System.Windows.Forms.Label();
            this.D1j1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Deck2J2 = new System.Windows.Forms.Label();
            this.S2J2 = new System.Windows.Forms.Label();
            this.Def2J2 = new System.Windows.Forms.Label();
            this.A2J2 = new System.Windows.Forms.Label();
            this.V2J2 = new System.Windows.Forms.Label();
            this.D2j2 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.Deck2P1 = new System.Windows.Forms.Label();
            this.S2J1 = new System.Windows.Forms.Label();
            this.Def2J1 = new System.Windows.Forms.Label();
            this.A2J1 = new System.Windows.Forms.Label();
            this.V2J1 = new System.Windows.Forms.Label();
            this.D2j1 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Res = new System.Windows.Forms.Label();
            this.EE = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // Regresar
            // 
            this.Regresar.Location = new System.Drawing.Point(12, 602);
            this.Regresar.Name = "Regresar";
            this.Regresar.Size = new System.Drawing.Size(76, 31);
            this.Regresar.TabIndex = 0;
            this.Regresar.Text = "Regresar";
            this.Regresar.UseVisualStyleBackColor = true;
            this.Regresar.Click += new System.EventHandler(this.Regresar_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.IndianRed;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(332, 204);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(139, 65);
            this.button2.TabIndex = 1;
            this.button2.Text = "Simular";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.RosyBrown;
            this.groupBox2.Controls.Add(this.Deck1J2);
            this.groupBox2.Controls.Add(this.S1J2);
            this.groupBox2.Controls.Add(this.Def1J2);
            this.groupBox2.Controls.Add(this.A1J2);
            this.groupBox2.Controls.Add(this.V1J2);
            this.groupBox2.Controls.Add(this.D1j2);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.pictureBox4);
            this.groupBox2.Location = new System.Drawing.Point(477, 92);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(312, 289);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox2";
            // 
            // Deck1J2
            // 
            this.Deck1J2.AutoSize = true;
            this.Deck1J2.Location = new System.Drawing.Point(12, 21);
            this.Deck1J2.Name = "Deck1J2";
            this.Deck1J2.Size = new System.Drawing.Size(115, 13);
            this.Deck1J2.TabIndex = 40;
            this.Deck1J2.Text = "La venganza del noble";
            // 
            // S1J2
            // 
            this.S1J2.AutoSize = true;
            this.S1J2.Location = new System.Drawing.Point(247, 231);
            this.S1J2.Name = "S1J2";
            this.S1J2.Size = new System.Drawing.Size(48, 13);
            this.S1J2.TabIndex = 37;
            this.S1J2.Text = "Sinergia:";
            // 
            // Def1J2
            // 
            this.Def1J2.AutoSize = true;
            this.Def1J2.Location = new System.Drawing.Point(179, 231);
            this.Def1J2.Name = "Def1J2";
            this.Def1J2.Size = new System.Drawing.Size(50, 13);
            this.Def1J2.TabIndex = 36;
            this.Def1J2.Text = "Defensa:";
            // 
            // A1J2
            // 
            this.A1J2.AutoSize = true;
            this.A1J2.Location = new System.Drawing.Point(123, 231);
            this.A1J2.Name = "A1J2";
            this.A1J2.Size = new System.Drawing.Size(44, 13);
            this.A1J2.TabIndex = 35;
            this.A1J2.Text = "Ataque:";
            // 
            // V1J2
            // 
            this.V1J2.AutoSize = true;
            this.V1J2.Location = new System.Drawing.Point(71, 231);
            this.V1J2.Name = "V1J2";
            this.V1J2.Size = new System.Drawing.Size(31, 13);
            this.V1J2.TabIndex = 34;
            this.V1J2.Text = "Vida:";
            // 
            // D1j2
            // 
            this.D1j2.AutoSize = true;
            this.D1j2.Location = new System.Drawing.Point(17, 231);
            this.D1j2.Name = "D1j2";
            this.D1j2.Size = new System.Drawing.Size(36, 13);
            this.D1j2.TabIndex = 33;
            this.D1j2.Text = "Daño:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(102, 58);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(19, 13);
            this.label26.TabIndex = 26;
            this.label26.Text = "26";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(38, 58);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(19, 13);
            this.label25.TabIndex = 25;
            this.label25.Text = "25";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(219, 181);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(19, 13);
            this.label24.TabIndex = 24;
            this.label24.Text = "24";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(95, 49);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(19, 13);
            this.label18.TabIndex = 23;
            this.label18.Text = "18";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(31, 50);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(19, 13);
            this.label17.TabIndex = 22;
            this.label17.Text = "17";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(155, 193);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(19, 13);
            this.label15.TabIndex = 21;
            this.label15.Text = "15";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(25, 193);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(19, 13);
            this.label13.TabIndex = 21;
            this.label13.Text = "13";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(93, 58);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(19, 13);
            this.label10.TabIndex = 20;
            this.label10.Text = "10";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
            this.pictureBox4.Location = new System.Drawing.Point(31, 50);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(251, 158);
            this.pictureBox4.TabIndex = 12;
            this.pictureBox4.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.RosyBrown;
            this.groupBox1.Controls.Add(this.Deck1J1);
            this.groupBox1.Controls.Add(this.S1J1);
            this.groupBox1.Controls.Add(this.Def1J1);
            this.groupBox1.Controls.Add(this.A1J1);
            this.groupBox1.Controls.Add(this.V1J1);
            this.groupBox1.Controls.Add(this.D1j1);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Location = new System.Drawing.Point(13, 92);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(313, 289);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // Deck1J1
            // 
            this.Deck1J1.AutoSize = true;
            this.Deck1J1.Location = new System.Drawing.Point(6, 21);
            this.Deck1J1.Name = "Deck1J1";
            this.Deck1J1.Size = new System.Drawing.Size(78, 13);
            this.Deck1J1.TabIndex = 39;
            this.Deck1J1.Text = "Torre del noble";
            // 
            // S1J1
            // 
            this.S1J1.AutoSize = true;
            this.S1J1.Location = new System.Drawing.Point(241, 231);
            this.S1J1.Name = "S1J1";
            this.S1J1.Size = new System.Drawing.Size(48, 13);
            this.S1J1.TabIndex = 31;
            this.S1J1.Text = "Sinergia:";
            // 
            // Def1J1
            // 
            this.Def1J1.AutoSize = true;
            this.Def1J1.Location = new System.Drawing.Point(172, 231);
            this.Def1J1.Name = "Def1J1";
            this.Def1J1.Size = new System.Drawing.Size(50, 13);
            this.Def1J1.TabIndex = 30;
            this.Def1J1.Text = "Defensa:";
            // 
            // A1J1
            // 
            this.A1J1.AutoSize = true;
            this.A1J1.Location = new System.Drawing.Point(117, 231);
            this.A1J1.Name = "A1J1";
            this.A1J1.Size = new System.Drawing.Size(44, 13);
            this.A1J1.TabIndex = 29;
            this.A1J1.Text = "Ataque:";
            // 
            // V1J1
            // 
            this.V1J1.AutoSize = true;
            this.V1J1.Location = new System.Drawing.Point(68, 231);
            this.V1J1.Name = "V1J1";
            this.V1J1.Size = new System.Drawing.Size(31, 13);
            this.V1J1.TabIndex = 28;
            this.V1J1.Text = "Vida:";
            // 
            // D1j1
            // 
            this.D1j1.AutoSize = true;
            this.D1j1.Location = new System.Drawing.Point(20, 231);
            this.D1j1.Name = "D1j1";
            this.D1j1.Size = new System.Drawing.Size(36, 13);
            this.D1j1.TabIndex = 27;
            this.D1j1.Text = "Daño:";
            this.D1j1.Click += new System.EventHandler(this.D1j1_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(221, 181);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(13, 13);
            this.label8.TabIndex = 18;
            this.label8.Text = "8";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(161, 181);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(13, 13);
            this.label7.TabIndex = 17;
            this.label7.Text = "7";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(99, 181);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(13, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "6";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(28, 181);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(13, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "5";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(221, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(13, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "4";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(161, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(13, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "3";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(99, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(13, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(13, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.Location = new System.Drawing.Point(28, 50);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(253, 158);
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Teal;
            this.groupBox3.Controls.Add(this.Deck2J2);
            this.groupBox3.Controls.Add(this.S2J2);
            this.groupBox3.Controls.Add(this.Def2J2);
            this.groupBox3.Controls.Add(this.A2J2);
            this.groupBox3.Controls.Add(this.V2J2);
            this.groupBox3.Controls.Add(this.D2j2);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.label32);
            this.groupBox3.Controls.Add(this.label31);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.label30);
            this.groupBox3.Controls.Add(this.label29);
            this.groupBox3.Controls.Add(this.label28);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.pictureBox3);
            this.groupBox3.Location = new System.Drawing.Point(476, 92);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(312, 289);
            this.groupBox3.TabIndex = 15;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "groupBox3";
            // 
            // Deck2J2
            // 
            this.Deck2J2.AutoSize = true;
            this.Deck2J2.Location = new System.Drawing.Point(12, 25);
            this.Deck2J2.Name = "Deck2J2";
            this.Deck2J2.Size = new System.Drawing.Size(95, 13);
            this.Deck2J2.TabIndex = 58;
            this.Deck2J2.Text = "Las tierras oscuras";
            // 
            // S2J2
            // 
            this.S2J2.AutoSize = true;
            this.S2J2.Location = new System.Drawing.Point(247, 231);
            this.S2J2.Name = "S2J2";
            this.S2J2.Size = new System.Drawing.Size(48, 13);
            this.S2J2.TabIndex = 57;
            this.S2J2.Text = "Sinergia:";
            // 
            // Def2J2
            // 
            this.Def2J2.AutoSize = true;
            this.Def2J2.Location = new System.Drawing.Point(179, 231);
            this.Def2J2.Name = "Def2J2";
            this.Def2J2.Size = new System.Drawing.Size(50, 13);
            this.Def2J2.TabIndex = 56;
            this.Def2J2.Text = "Defensa:";
            // 
            // A2J2
            // 
            this.A2J2.AutoSize = true;
            this.A2J2.Location = new System.Drawing.Point(123, 231);
            this.A2J2.Name = "A2J2";
            this.A2J2.Size = new System.Drawing.Size(38, 13);
            this.A2J2.TabIndex = 55;
            this.A2J2.Text = "Atque:";
            // 
            // V2J2
            // 
            this.V2J2.AutoSize = true;
            this.V2J2.Location = new System.Drawing.Point(71, 231);
            this.V2J2.Name = "V2J2";
            this.V2J2.Size = new System.Drawing.Size(31, 13);
            this.V2J2.TabIndex = 54;
            this.V2J2.Text = "Vida:";
            // 
            // D2j2
            // 
            this.D2j2.AutoSize = true;
            this.D2j2.Location = new System.Drawing.Point(12, 231);
            this.D2j2.Name = "D2j2";
            this.D2j2.Size = new System.Drawing.Size(36, 13);
            this.D2j2.TabIndex = 53;
            this.D2j2.Text = "Daño:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(225, 193);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(19, 13);
            this.label32.TabIndex = 52;
            this.label32.Text = "32";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label32.Click += new System.EventHandler(this.label32_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(163, 193);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(19, 13);
            this.label31.TabIndex = 51;
            this.label31.Text = "31";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label31.Click += new System.EventHandler(this.label31_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(102, 193);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(19, 13);
            this.label30.TabIndex = 50;
            this.label30.Text = "30";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label30.Click += new System.EventHandler(this.label30_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(38, 193);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(19, 13);
            this.label29.TabIndex = 49;
            this.label29.Text = "29";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(225, 58);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(19, 13);
            this.label28.TabIndex = 48;
            this.label28.Text = "28";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(163, 58);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(19, 13);
            this.label27.TabIndex = 47;
            this.label27.Text = "27";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(93, 193);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(19, 13);
            this.label14.TabIndex = 46;
            this.label14.Text = "14";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(155, 58);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(19, 13);
            this.label11.TabIndex = 45;
            this.label11.Text = "11";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.Location = new System.Drawing.Point(38, 58);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(248, 158);
            this.pictureBox3.TabIndex = 44;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Teal;
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.Deck2P1);
            this.groupBox4.Controls.Add(this.S2J1);
            this.groupBox4.Controls.Add(this.Def2J1);
            this.groupBox4.Controls.Add(this.A2J1);
            this.groupBox4.Controls.Add(this.V2J1);
            this.groupBox4.Controls.Add(this.D2j1);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.pictureBox2);
            this.groupBox4.Location = new System.Drawing.Point(12, 92);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(313, 289);
            this.groupBox4.TabIndex = 16;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "groupBox4";
            // 
            // Deck2P1
            // 
            this.Deck2P1.AutoSize = true;
            this.Deck2P1.Location = new System.Drawing.Point(6, 25);
            this.Deck2P1.Name = "Deck2P1";
            this.Deck2P1.Size = new System.Drawing.Size(95, 13);
            this.Deck2P1.TabIndex = 53;
            this.Deck2P1.Text = "Defensiva Barbara";
            // 
            // S2J1
            // 
            this.S2J1.AutoSize = true;
            this.S2J1.Location = new System.Drawing.Point(246, 231);
            this.S2J1.Name = "S2J1";
            this.S2J1.Size = new System.Drawing.Size(48, 13);
            this.S2J1.TabIndex = 52;
            this.S2J1.Text = "Sinergia:";
            // 
            // Def2J1
            // 
            this.Def2J1.AutoSize = true;
            this.Def2J1.Location = new System.Drawing.Point(177, 231);
            this.Def2J1.Name = "Def2J1";
            this.Def2J1.Size = new System.Drawing.Size(50, 13);
            this.Def2J1.TabIndex = 51;
            this.Def2J1.Text = "Defensa:";
            // 
            // A2J1
            // 
            this.A2J1.AutoSize = true;
            this.A2J1.Location = new System.Drawing.Point(122, 231);
            this.A2J1.Name = "A2J1";
            this.A2J1.Size = new System.Drawing.Size(44, 13);
            this.A2J1.TabIndex = 50;
            this.A2J1.Text = "Ataque:";
            // 
            // V2J1
            // 
            this.V2J1.AutoSize = true;
            this.V2J1.Location = new System.Drawing.Point(67, 231);
            this.V2J1.Name = "V2J1";
            this.V2J1.Size = new System.Drawing.Size(31, 13);
            this.V2J1.TabIndex = 49;
            this.V2J1.Text = "Vida:";
            // 
            // D2j1
            // 
            this.D2j1.AutoSize = true;
            this.D2j1.Location = new System.Drawing.Point(11, 231);
            this.D2j1.Name = "D2j1";
            this.D2j1.Size = new System.Drawing.Size(36, 13);
            this.D2j1.TabIndex = 48;
            this.D2j1.Text = "Daño:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(158, 181);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(19, 13);
            this.label23.TabIndex = 47;
            this.label23.Text = "23";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(95, 181);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(19, 13);
            this.label22.TabIndex = 46;
            this.label22.Text = "22";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(31, 181);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(19, 13);
            this.label21.TabIndex = 45;
            this.label21.Text = "21";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(219, 50);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(19, 13);
            this.label20.TabIndex = 44;
            this.label20.Text = "20";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(158, 50);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(19, 13);
            this.label19.TabIndex = 43;
            this.label19.Text = "19";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(221, 193);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(19, 13);
            this.label16.TabIndex = 42;
            this.label16.Text = "16";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(221, 58);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(19, 13);
            this.label12.TabIndex = 41;
            this.label12.Text = "12";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(28, 58);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(13, 13);
            this.label9.TabIndex = 40;
            this.label9.Text = "9";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.Location = new System.Drawing.Point(27, 58);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(254, 158);
            this.pictureBox2.TabIndex = 39;
            this.pictureBox2.TabStop = false;
            // 
            // Res
            // 
            this.Res.Location = new System.Drawing.Point(210, 396);
            this.Res.Name = "Res";
            this.Res.Size = new System.Drawing.Size(427, 196);
            this.Res.TabIndex = 17;
            this.Res.Text = "Resultado final";
            this.Res.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // EE
            // 
            this.EE.Location = new System.Drawing.Point(712, 602);
            this.EE.Name = "EE";
            this.EE.Size = new System.Drawing.Size(76, 31);
            this.EE.TabIndex = 18;
            this.EE.Text = "No tocar";
            this.EE.UseVisualStyleBackColor = true;
            this.EE.Click += new System.EventHandler(this.EE_Click);
            // 
            // Pelea
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 645);
            this.Controls.Add(this.EE);
            this.Controls.Add(this.Res);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Regresar);
            this.Name = "Pelea";
            this.Text = "Pelea";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button Regresar;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label S1J2;
        private System.Windows.Forms.Label Def1J2;
        private System.Windows.Forms.Label A1J2;
        private System.Windows.Forms.Label V1J2;
        private System.Windows.Forms.Label D1j2;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label S1J1;
        private System.Windows.Forms.Label Def1J1;
        private System.Windows.Forms.Label A1J1;
        private System.Windows.Forms.Label V1J1;
        private System.Windows.Forms.Label D1j1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label Deck1J2;
        private System.Windows.Forms.Label Deck1J1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label Deck2J2;
        private System.Windows.Forms.Label S2J2;
        private System.Windows.Forms.Label Def2J2;
        private System.Windows.Forms.Label A2J2;
        private System.Windows.Forms.Label V2J2;
        private System.Windows.Forms.Label D2j2;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label Deck2P1;
        private System.Windows.Forms.Label S2J1;
        private System.Windows.Forms.Label Def2J1;
        private System.Windows.Forms.Label A2J1;
        private System.Windows.Forms.Label V2J1;
        private System.Windows.Forms.Label D2j1;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label Res;
        private System.Windows.Forms.Button EE;
    }
}