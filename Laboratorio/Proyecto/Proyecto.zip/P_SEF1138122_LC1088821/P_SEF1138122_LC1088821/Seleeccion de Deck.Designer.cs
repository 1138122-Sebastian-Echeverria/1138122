﻿namespace P_SEF1138122_LC1088821
{
    partial class Seleeccion_de_Deck
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Seleeccion_de_Deck));
            this.button1 = new System.Windows.Forms.Button();
            this.Regreso = new System.Windows.Forms.Button();
            this.Deck1J1 = new System.Windows.Forms.RadioButton();
            this.Deck2J1 = new System.Windows.Forms.RadioButton();
            this.Deck1J2 = new System.Windows.Forms.RadioButton();
            this.Deck2J2 = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.HintP1 = new System.Windows.Forms.Label();
            this.S2J1 = new System.Windows.Forms.Label();
            this.Def2J1 = new System.Windows.Forms.Label();
            this.A2J1 = new System.Windows.Forms.Label();
            this.V2J1 = new System.Windows.Forms.Label();
            this.D2j1 = new System.Windows.Forms.Label();
            this.S1J1 = new System.Windows.Forms.Label();
            this.Def1J1 = new System.Windows.Forms.Label();
            this.A1J1 = new System.Windows.Forms.Label();
            this.V1J1 = new System.Windows.Forms.Label();
            this.D1j1 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.HintP2 = new System.Windows.Forms.Label();
            this.S2J2 = new System.Windows.Forms.Label();
            this.Def2J2 = new System.Windows.Forms.Label();
            this.A2J2 = new System.Windows.Forms.Label();
            this.V2J2 = new System.Windows.Forms.Label();
            this.D2j2 = new System.Windows.Forms.Label();
            this.S1J2 = new System.Windows.Forms.Label();
            this.Def1J2 = new System.Windows.Forms.Label();
            this.A1J2 = new System.Windows.Forms.Label();
            this.V1J2 = new System.Windows.Forms.Label();
            this.D1j2 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(333, 600);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 43);
            this.button1.TabIndex = 3;
            this.button1.Text = "Siguiente";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Regreso
            // 
            this.Regreso.Location = new System.Drawing.Point(12, 600);
            this.Regreso.Name = "Regreso";
            this.Regreso.Size = new System.Drawing.Size(106, 43);
            this.Regreso.TabIndex = 6;
            this.Regreso.Text = "Regresar";
            this.Regreso.UseVisualStyleBackColor = true;
            this.Regreso.Click += new System.EventHandler(this.Regreso_Click);
            // 
            // Deck1J1
            // 
            this.Deck1J1.AutoSize = true;
            this.Deck1J1.Location = new System.Drawing.Point(6, 19);
            this.Deck1J1.Name = "Deck1J1";
            this.Deck1J1.Size = new System.Drawing.Size(98, 17);
            this.Deck1J1.TabIndex = 7;
            this.Deck1J1.TabStop = true;
            this.Deck1J1.Text = "Torre del Noble";
            this.Deck1J1.UseVisualStyleBackColor = true;
            // 
            // Deck2J1
            // 
            this.Deck2J1.AutoSize = true;
            this.Deck2J1.Location = new System.Drawing.Point(6, 227);
            this.Deck2J1.Name = "Deck2J1";
            this.Deck2J1.Size = new System.Drawing.Size(113, 17);
            this.Deck2J1.TabIndex = 8;
            this.Deck2J1.TabStop = true;
            this.Deck2J1.Text = "Defensiva Barbara";
            this.Deck2J1.UseVisualStyleBackColor = true;
            // 
            // Deck1J2
            // 
            this.Deck1J2.AutoSize = true;
            this.Deck1J2.Location = new System.Drawing.Point(6, 19);
            this.Deck1J2.Name = "Deck1J2";
            this.Deck1J2.Size = new System.Drawing.Size(133, 17);
            this.Deck1J2.TabIndex = 9;
            this.Deck1J2.TabStop = true;
            this.Deck1J2.Text = "La venganza del noble";
            this.Deck1J2.UseVisualStyleBackColor = true;
            // 
            // Deck2J2
            // 
            this.Deck2J2.AutoSize = true;
            this.Deck2J2.Location = new System.Drawing.Point(6, 227);
            this.Deck2J2.Name = "Deck2J2";
            this.Deck2J2.Size = new System.Drawing.Size(113, 17);
            this.Deck2J2.TabIndex = 10;
            this.Deck2J2.TabStop = true;
            this.Deck2J2.Text = "Las tierras oscuras";
            this.Deck2J2.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.RosyBrown;
            this.groupBox1.Controls.Add(this.HintP1);
            this.groupBox1.Controls.Add(this.S2J1);
            this.groupBox1.Controls.Add(this.Def2J1);
            this.groupBox1.Controls.Add(this.A2J1);
            this.groupBox1.Controls.Add(this.V2J1);
            this.groupBox1.Controls.Add(this.D2j1);
            this.groupBox1.Controls.Add(this.S1J1);
            this.groupBox1.Controls.Add(this.Def1J1);
            this.groupBox1.Controls.Add(this.A1J1);
            this.groupBox1.Controls.Add(this.V1J1);
            this.groupBox1.Controls.Add(this.D1j1);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.Deck1J1);
            this.groupBox1.Controls.Add(this.Deck2J1);
            this.groupBox1.Location = new System.Drawing.Point(12, 21);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(347, 573);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // HintP1
            // 
            this.HintP1.BackColor = System.Drawing.Color.Snow;
            this.HintP1.Location = new System.Drawing.Point(6, 433);
            this.HintP1.Name = "HintP1";
            this.HintP1.Size = new System.Drawing.Size(301, 137);
            this.HintP1.TabIndex = 37;
            this.HintP1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // S2J1
            // 
            this.S2J1.AutoSize = true;
            this.S2J1.BackColor = System.Drawing.Color.IndianRed;
            this.S2J1.Location = new System.Drawing.Point(280, 397);
            this.S2J1.Name = "S2J1";
            this.S2J1.Size = new System.Drawing.Size(48, 13);
            this.S2J1.TabIndex = 36;
            this.S2J1.Text = "Sinergia:";
            // 
            // Def2J1
            // 
            this.Def2J1.AutoSize = true;
            this.Def2J1.BackColor = System.Drawing.Color.IndianRed;
            this.Def2J1.Location = new System.Drawing.Point(278, 359);
            this.Def2J1.Name = "Def2J1";
            this.Def2J1.Size = new System.Drawing.Size(50, 13);
            this.Def2J1.TabIndex = 35;
            this.Def2J1.Text = "Defensa:";
            // 
            // A2J1
            // 
            this.A2J1.AutoSize = true;
            this.A2J1.BackColor = System.Drawing.Color.IndianRed;
            this.A2J1.Location = new System.Drawing.Point(280, 322);
            this.A2J1.Name = "A2J1";
            this.A2J1.Size = new System.Drawing.Size(38, 13);
            this.A2J1.TabIndex = 34;
            this.A2J1.Text = "Atque:";
            // 
            // V2J1
            // 
            this.V2J1.AutoSize = true;
            this.V2J1.BackColor = System.Drawing.Color.IndianRed;
            this.V2J1.Location = new System.Drawing.Point(280, 285);
            this.V2J1.Name = "V2J1";
            this.V2J1.Size = new System.Drawing.Size(31, 13);
            this.V2J1.TabIndex = 33;
            this.V2J1.Text = "Vida:";
            // 
            // D2j1
            // 
            this.D2j1.AutoSize = true;
            this.D2j1.BackColor = System.Drawing.Color.IndianRed;
            this.D2j1.Location = new System.Drawing.Point(279, 248);
            this.D2j1.Name = "D2j1";
            this.D2j1.Size = new System.Drawing.Size(36, 13);
            this.D2j1.TabIndex = 32;
            this.D2j1.Text = "Daño:";
            // 
            // S1J1
            // 
            this.S1J1.AutoSize = true;
            this.S1J1.BackColor = System.Drawing.Color.IndianRed;
            this.S1J1.Location = new System.Drawing.Point(280, 194);
            this.S1J1.Name = "S1J1";
            this.S1J1.Size = new System.Drawing.Size(48, 13);
            this.S1J1.TabIndex = 31;
            this.S1J1.Text = "Sinergia:";
            // 
            // Def1J1
            // 
            this.Def1J1.AutoSize = true;
            this.Def1J1.BackColor = System.Drawing.Color.IndianRed;
            this.Def1J1.Location = new System.Drawing.Point(279, 155);
            this.Def1J1.Name = "Def1J1";
            this.Def1J1.Size = new System.Drawing.Size(50, 13);
            this.Def1J1.TabIndex = 30;
            this.Def1J1.Text = "Defensa:";
            // 
            // A1J1
            // 
            this.A1J1.AutoSize = true;
            this.A1J1.BackColor = System.Drawing.Color.IndianRed;
            this.A1J1.Location = new System.Drawing.Point(279, 115);
            this.A1J1.Name = "A1J1";
            this.A1J1.Size = new System.Drawing.Size(38, 13);
            this.A1J1.TabIndex = 29;
            this.A1J1.Text = "Atque:";
            // 
            // V1J1
            // 
            this.V1J1.AutoSize = true;
            this.V1J1.BackColor = System.Drawing.Color.IndianRed;
            this.V1J1.Location = new System.Drawing.Point(280, 76);
            this.V1J1.Name = "V1J1";
            this.V1J1.Size = new System.Drawing.Size(31, 13);
            this.V1J1.TabIndex = 28;
            this.V1J1.Text = "Vida:";
            // 
            // D1j1
            // 
            this.D1j1.AutoSize = true;
            this.D1j1.BackColor = System.Drawing.Color.IndianRed;
            this.D1j1.Location = new System.Drawing.Point(279, 37);
            this.D1j1.Name = "D1j1";
            this.D1j1.Size = new System.Drawing.Size(36, 13);
            this.D1j1.TabIndex = 27;
            this.D1j1.Text = "Daño:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(206, 403);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(46, 26);
            this.label23.TabIndex = 26;
            this.label23.Text = "Monta\r\nPuercos";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(14, 407);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(49, 13);
            this.label22.TabIndex = 25;
            this.label22.Text = "Barbaros";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(207, 256);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(43, 13);
            this.label21.TabIndex = 24;
            this.label21.Text = "Mortero";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(138, 248);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(56, 26);
            this.label20.TabIndex = 23;
            this.label20.Text = "Banda de \r\nGoblings";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(79, 256);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(46, 13);
            this.label19.TabIndex = 22;
            this.label19.Text = "Aqueras";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(139, 404);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 26);
            this.label16.TabIndex = 21;
            this.label16.Text = "Mini\r\nP.e.k.k.a.\r\n";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(78, 407);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(46, 26);
            this.label12.TabIndex = 20;
            this.label12.Text = "Bola de \r\nfuego";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(25, 255);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 13);
            this.label9.TabIndex = 19;
            this.label9.Text = "Zap!";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(213, 197);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(34, 13);
            this.label8.TabIndex = 18;
            this.label8.Text = "Mago";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(144, 195);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 26);
            this.label7.TabIndex = 17;
            this.label7.Text = "Torre \r\nInfernal";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(78, 195);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 26);
            this.label6.TabIndex = 16;
            this.label6.Text = "Arete de \r\nbatalla";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 195);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "Valkiria";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(207, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 26);
            this.label4.TabIndex = 14;
            this.label4.Text = "Bola de \r\nfuego";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(144, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 26);
            this.label3.TabIndex = 13;
            this.label3.Text = "Gigante \r\nNoble";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(90, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "Zap!";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Murcielagos";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.Location = new System.Drawing.Point(7, 261);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(300, 158);
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.Location = new System.Drawing.Point(7, 50);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(300, 158);
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.RosyBrown;
            this.groupBox2.Controls.Add(this.HintP2);
            this.groupBox2.Controls.Add(this.S2J2);
            this.groupBox2.Controls.Add(this.Def2J2);
            this.groupBox2.Controls.Add(this.A2J2);
            this.groupBox2.Controls.Add(this.V2J2);
            this.groupBox2.Controls.Add(this.D2j2);
            this.groupBox2.Controls.Add(this.S1J2);
            this.groupBox2.Controls.Add(this.Def1J2);
            this.groupBox2.Controls.Add(this.A1J2);
            this.groupBox2.Controls.Add(this.V1J2);
            this.groupBox2.Controls.Add(this.D1j2);
            this.groupBox2.Controls.Add(this.label32);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.pictureBox4);
            this.groupBox2.Controls.Add(this.pictureBox3);
            this.groupBox2.Controls.Add(this.Deck1J2);
            this.groupBox2.Controls.Add(this.Deck2J2);
            this.groupBox2.Location = new System.Drawing.Point(408, 21);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(345, 573);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox2";
            // 
            // HintP2
            // 
            this.HintP2.BackColor = System.Drawing.Color.Snow;
            this.HintP2.Location = new System.Drawing.Point(5, 433);
            this.HintP2.Name = "HintP2";
            this.HintP2.Size = new System.Drawing.Size(301, 137);
            this.HintP2.TabIndex = 38;
            this.HintP2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // S2J2
            // 
            this.S2J2.AutoSize = true;
            this.S2J2.BackColor = System.Drawing.Color.IndianRed;
            this.S2J2.Location = new System.Drawing.Point(279, 397);
            this.S2J2.Name = "S2J2";
            this.S2J2.Size = new System.Drawing.Size(48, 13);
            this.S2J2.TabIndex = 42;
            this.S2J2.Text = "Sinergia:";
            // 
            // Def2J2
            // 
            this.Def2J2.AutoSize = true;
            this.Def2J2.BackColor = System.Drawing.Color.IndianRed;
            this.Def2J2.Location = new System.Drawing.Point(279, 359);
            this.Def2J2.Name = "Def2J2";
            this.Def2J2.Size = new System.Drawing.Size(50, 13);
            this.Def2J2.TabIndex = 41;
            this.Def2J2.Text = "Defensa:";
            // 
            // A2J2
            // 
            this.A2J2.AutoSize = true;
            this.A2J2.BackColor = System.Drawing.Color.IndianRed;
            this.A2J2.Location = new System.Drawing.Point(279, 322);
            this.A2J2.Name = "A2J2";
            this.A2J2.Size = new System.Drawing.Size(38, 13);
            this.A2J2.TabIndex = 40;
            this.A2J2.Text = "Atque:";
            // 
            // V2J2
            // 
            this.V2J2.AutoSize = true;
            this.V2J2.BackColor = System.Drawing.Color.IndianRed;
            this.V2J2.Location = new System.Drawing.Point(281, 285);
            this.V2J2.Name = "V2J2";
            this.V2J2.Size = new System.Drawing.Size(31, 13);
            this.V2J2.TabIndex = 39;
            this.V2J2.Text = "Vida:";
            // 
            // D2j2
            // 
            this.D2j2.AutoSize = true;
            this.D2j2.BackColor = System.Drawing.Color.IndianRed;
            this.D2j2.Location = new System.Drawing.Point(279, 248);
            this.D2j2.Name = "D2j2";
            this.D2j2.Size = new System.Drawing.Size(36, 13);
            this.D2j2.TabIndex = 38;
            this.D2j2.Text = "Daño:";
            // 
            // S1J2
            // 
            this.S1J2.AutoSize = true;
            this.S1J2.BackColor = System.Drawing.Color.IndianRed;
            this.S1J2.Location = new System.Drawing.Point(275, 197);
            this.S1J2.Name = "S1J2";
            this.S1J2.Size = new System.Drawing.Size(48, 13);
            this.S1J2.TabIndex = 37;
            this.S1J2.Text = "Sinergia:";
            // 
            // Def1J2
            // 
            this.Def1J2.AutoSize = true;
            this.Def1J2.BackColor = System.Drawing.Color.IndianRed;
            this.Def1J2.Location = new System.Drawing.Point(274, 155);
            this.Def1J2.Name = "Def1J2";
            this.Def1J2.Size = new System.Drawing.Size(50, 13);
            this.Def1J2.TabIndex = 36;
            this.Def1J2.Text = "Defensa:";
            // 
            // A1J2
            // 
            this.A1J2.AutoSize = true;
            this.A1J2.BackColor = System.Drawing.Color.IndianRed;
            this.A1J2.Location = new System.Drawing.Point(274, 115);
            this.A1J2.Name = "A1J2";
            this.A1J2.Size = new System.Drawing.Size(38, 13);
            this.A1J2.TabIndex = 35;
            this.A1J2.Text = "Atque:";
            // 
            // V1J2
            // 
            this.V1J2.AutoSize = true;
            this.V1J2.BackColor = System.Drawing.Color.IndianRed;
            this.V1J2.Location = new System.Drawing.Point(274, 76);
            this.V1J2.Name = "V1J2";
            this.V1J2.Size = new System.Drawing.Size(31, 13);
            this.V1J2.TabIndex = 34;
            this.V1J2.Text = "Vida:";
            // 
            // D1j2
            // 
            this.D1j2.AutoSize = true;
            this.D1j2.BackColor = System.Drawing.Color.IndianRed;
            this.D1j2.Location = new System.Drawing.Point(274, 37);
            this.D1j2.Name = "D1j2";
            this.D1j2.Size = new System.Drawing.Size(36, 13);
            this.D1j2.TabIndex = 33;
            this.D1j2.Text = "Daño:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(194, 405);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(60, 13);
            this.label32.TabIndex = 32;
            this.label32.Text = "Cementerio";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(137, 401);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(51, 26);
            this.label31.TabIndex = 31;
            this.label31.Text = "Bruja\r\nNocturna";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(74, 401);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(48, 26);
            this.label30.TabIndex = 30;
            this.label30.Text = "Mago\r\nElectrico";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(12, 405);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(46, 13);
            this.label29.TabIndex = 29;
            this.label29.Text = "Bandida";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(200, 253);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(44, 13);
            this.label28.TabIndex = 28;
            this.label28.Text = "Gigante";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(8, 255);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(59, 13);
            this.label27.TabIndex = 27;
            this.label27.Text = "Esqueletos";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(201, 190);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(44, 26);
            this.label26.TabIndex = 26;
            this.label26.Text = "Arquero\r\nmagico";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(136, 193);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(48, 26);
            this.label25.TabIndex = 25;
            this.label25.Text = "Mago\r\nElectrico";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(76, 194);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(46, 13);
            this.label24.TabIndex = 24;
            this.label24.Text = "Bandida";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(10, 190);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 26);
            this.label18.TabIndex = 23;
            this.label18.Text = "Fantasma\r\nReal";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(195, 49);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(54, 13);
            this.label17.TabIndex = 22;
            this.label17.Text = "P.E.K.K.A";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(137, 46);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(50, 26);
            this.label15.TabIndex = 21;
            this.label15.Text = "Arete de \r\nbatalla";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(137, 251);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(46, 26);
            this.label14.TabIndex = 22;
            this.label14.Text = "Bola de \r\nfuego";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(76, 43);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(46, 26);
            this.label13.TabIndex = 21;
            this.label13.Text = "Bola de \r\nfuego";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(86, 253);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 13);
            this.label11.TabIndex = 21;
            this.label11.Text = "Zap!";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(24, 46);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 13);
            this.label10.TabIndex = 20;
            this.label10.Text = "Zap!";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
            this.pictureBox4.Location = new System.Drawing.Point(6, 50);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(300, 158);
            this.pictureBox4.TabIndex = 12;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.Location = new System.Drawing.Point(6, 261);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(300, 158);
            this.pictureBox3.TabIndex = 11;
            this.pictureBox3.TabStop = false;
            // 
            // Seleeccion_de_Deck
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(776, 655);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Regreso);
            this.Controls.Add(this.button1);
            this.Name = "Seleeccion_de_Deck";
            this.Text = "Seleeccion_de_Deck";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button Regreso;
        private System.Windows.Forms.RadioButton Deck1J1;
        private System.Windows.Forms.RadioButton Deck2J1;
        private System.Windows.Forms.RadioButton Deck1J2;
        private System.Windows.Forms.RadioButton Deck2J2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label Def1J1;
        private System.Windows.Forms.Label A1J1;
        private System.Windows.Forms.Label V1J1;
        private System.Windows.Forms.Label D1j1;
        private System.Windows.Forms.Label S2J1;
        private System.Windows.Forms.Label Def2J1;
        private System.Windows.Forms.Label A2J1;
        private System.Windows.Forms.Label V2J1;
        private System.Windows.Forms.Label D2j1;
        private System.Windows.Forms.Label S1J1;
        private System.Windows.Forms.Label S2J2;
        private System.Windows.Forms.Label Def2J2;
        private System.Windows.Forms.Label A2J2;
        private System.Windows.Forms.Label V2J2;
        private System.Windows.Forms.Label D2j2;
        private System.Windows.Forms.Label S1J2;
        private System.Windows.Forms.Label Def1J2;
        private System.Windows.Forms.Label A1J2;
        private System.Windows.Forms.Label V1J2;
        private System.Windows.Forms.Label D1j2;
        private System.Windows.Forms.Label HintP1;
        private System.Windows.Forms.Label HintP2;
    }
}