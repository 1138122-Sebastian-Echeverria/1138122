﻿namespace P_SEF1138122_LC1088821
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.NombreJ1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.ApellidoJ1 = new System.Windows.Forms.TextBox();
            this.ApellidoJ2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Apellido = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.NombreJ2 = new System.Windows.Forms.TextBox();
            this.EquipoJ1 = new System.Windows.Forms.TextBox();
            this.EquipoJ2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Indigo;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(239, 312);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 43);
            this.button1.TabIndex = 0;
            this.button1.Text = "Siguiente";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Indigo;
            this.pictureBox1.Location = new System.Drawing.Point(12, 92);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(233, 166);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Indigo;
            this.pictureBox2.Location = new System.Drawing.Point(334, 92);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(233, 166);
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.Location = new System.Drawing.Point(0, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(579, 368);
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // NombreJ1
            // 
            this.NombreJ1.Location = new System.Drawing.Point(79, 118);
            this.NombreJ1.Name = "NombreJ1";
            this.NombreJ1.Size = new System.Drawing.Size(100, 20);
            this.NombreJ1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(111, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Nombre";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(111, 148);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Apellido";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(111, 197);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Equipo";
            // 
            // ApellidoJ1
            // 
            this.ApellidoJ1.Location = new System.Drawing.Point(79, 164);
            this.ApellidoJ1.Name = "ApellidoJ1";
            this.ApellidoJ1.Size = new System.Drawing.Size(100, 20);
            this.ApellidoJ1.TabIndex = 14;
            // 
            // ApellidoJ2
            // 
            this.ApellidoJ2.Location = new System.Drawing.Point(405, 164);
            this.ApellidoJ2.Name = "ApellidoJ2";
            this.ApellidoJ2.Size = new System.Drawing.Size(100, 20);
            this.ApellidoJ2.TabIndex = 20;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(437, 197);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 13);
            this.label6.TabIndex = 18;
            this.label6.Text = "Equipo";
            // 
            // Apellido
            // 
            this.Apellido.AutoSize = true;
            this.Apellido.Location = new System.Drawing.Point(432, 148);
            this.Apellido.Name = "Apellido";
            this.Apellido.Size = new System.Drawing.Size(49, 13);
            this.Apellido.TabIndex = 17;
            this.Apellido.Text = "Apellidos";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(433, 102);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Nombre";
            // 
            // NombreJ2
            // 
            this.NombreJ2.Location = new System.Drawing.Point(405, 118);
            this.NombreJ2.Name = "NombreJ2";
            this.NombreJ2.Size = new System.Drawing.Size(100, 20);
            this.NombreJ2.TabIndex = 15;
            // 
            // EquipoJ1
            // 
            this.EquipoJ1.Location = new System.Drawing.Point(79, 213);
            this.EquipoJ1.Name = "EquipoJ1";
            this.EquipoJ1.Size = new System.Drawing.Size(100, 20);
            this.EquipoJ1.TabIndex = 21;
            // 
            // EquipoJ2
            // 
            this.EquipoJ2.Location = new System.Drawing.Point(405, 213);
            this.EquipoJ2.Name = "EquipoJ2";
            this.EquipoJ2.Size = new System.Drawing.Size(100, 20);
            this.EquipoJ2.TabIndex = 22;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Indigo;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 23.25F);
            this.label5.ForeColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(35, 28);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(494, 35);
            this.label5.TabIndex = 23;
            this.label5.Text = "Bienvenido a Clash Simulator 2022";
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.Indigo;
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(381, 301);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(186, 57);
            this.label7.TabIndex = 24;
            this.label7.Text = "Hecho por:\r\nSebastian Echeverria 1138122\r\ny\r\nLaura Calderon 1088821";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(579, 367);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.EquipoJ2);
            this.Controls.Add(this.EquipoJ1);
            this.Controls.Add(this.ApellidoJ2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Apellido);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.NombreJ2);
            this.Controls.Add(this.ApellidoJ1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.NombreJ1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox3);
            this.Name = "Form1";
            this.Text = " ";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TextBox NombreJ1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox ApellidoJ1;
        private System.Windows.Forms.TextBox ApellidoJ2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label Apellido;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox NombreJ2;
        private System.Windows.Forms.TextBox EquipoJ1;
        private System.Windows.Forms.TextBox EquipoJ2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
    }
}

