﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P_SEF1138122_LC1088821
{
    internal class Nombre_de_jugadores
    {
        string Jugador1;
        string Jugador2;

        public Nombre_de_jugadores(string Nombre1, string nombre2)
        {
            Jugador1 = Nombre1;
            Jugador2 = nombre2;
        }
    }
}
