﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P_SEF1138122_LC1088821
{
    public partial class Pelea : Form
    {
        public Pelea()
        {
            InitializeComponent();
        }
    }
}
