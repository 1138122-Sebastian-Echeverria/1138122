﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T5_P2_SebastianEcheverria_1138122
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool Continuar = true;
            double Monto, Descuento = 0;
            string codigo;

            while (Continuar == true)   
            {
                Console.Clear();
                try
                {
                    Console.WriteLine("Ingrese el monto de compra");
                    Monto = double.Parse(Console.ReadLine());

                    Console.WriteLine("");

                    Console.WriteLine("Tiene codigo de descuento? Si o No");
                    codigo = Console.ReadLine();

                    Console.WriteLine("");

                    if (codigo == "Si")
                    {
                        if (Monto < 400)
                        {
                            Console.WriteLine("Solo hay descuento por el codigo.");
                            Console.WriteLine("");
                            Descuento = Monto - (Monto * 0.05);
                            Console.WriteLine("El monto total a pagar es de Q" + Descuento);
                        }
                        else if (Monto <= 1000)
                        {
                            Console.WriteLine("El descuento es de 7% más el codigo de descuento sobre " + Monto + ":");
                            Descuento = Monto - ((Monto * 0.07) + (Monto * 0.05));
                            Console.WriteLine("");
                            Console.WriteLine("El monto total a pagar es de Q" + Descuento);
                        }
                        else if (Monto <= 5000)
                        {
                            Console.WriteLine("El descuento es de 10% más el codigo de descuento sobre " + Monto + ":");
                            Descuento = Monto - ((Monto * 0.1) + (Monto * 0.05));
                            Console.WriteLine("");
                            Console.WriteLine("El monto total a pagar es de Q" + Descuento);
                        }
                        else if (Monto <= 15000)
                        {
                            Console.WriteLine("El descuento es de 15% más el codigo de descuento sobre " + Monto + ":");
                            Descuento = Monto - ((Monto * 0.15) + (Monto * 0.05));
                            Console.WriteLine("");
                            Console.WriteLine("El monto total a pagar es de Q" + Descuento);
                        }
                        else if (Monto > 15000)
                        {
                            Console.WriteLine("El descuento es de 25% más el codigo de descuento sobre " + Monto + ":");
                            Descuento = Monto - ((Monto * 0.25) + (Monto * 0.05));
                            Console.WriteLine("");
                            Console.WriteLine("El monto total a pagar es de Q" + Descuento);
                        }
                        Continuar = false;
                    }
                    else if (codigo == "No")
                    {
                        if (Monto < 400)
                        {
                            Console.WriteLine("No hay descuento.");
                            Console.WriteLine("");
                            Console.WriteLine("El monto total a pagar es de Q" + Monto);
                        }
                        else if (Monto <= 1000)
                        {
                            Console.WriteLine("El descuento es de 7% " + Monto + ":");
                            Descuento = Monto - (Monto * 0.07);
                            Console.WriteLine("");
                            Console.WriteLine("El monto total a pagar es de Q" + Descuento);
                        }
                        else if (Monto <= 5000)
                        {
                            Console.WriteLine("El descuento es de 10% a " + Monto + ":");
                            Descuento = Monto - (Monto * 0.1);
                            Console.WriteLine("");
                            Console.WriteLine("El monto total a pagar es de Q" + Descuento);
                        }
                        else if (Monto <= 15000)
                        {
                            Console.WriteLine("El descuento es de 15% a " + Monto + ":");
                            Descuento = Monto - (Monto * 0.15);
                            Console.WriteLine("");
                            Console.WriteLine("El monto total a pagar es de Q" + Descuento);
                        }
                        else if (Monto > 15000)
                        {
                            Console.WriteLine("El descuento es de 25% a " + Monto + ":");
                            Descuento = Monto - (Monto * 0.25);
                            Console.WriteLine("");
                            Console.WriteLine("El monto total a pagar es de Q" + Descuento);
                        }
                        Continuar = false;
                    }
                    else
                    {
                        Console.WriteLine("Ingrese solamente Si o No. Primera letra mayuscula y segunda letra minuscula");
                    }
                    
                }
                catch (FormatException)
                {
                    Console.WriteLine("No hay ningun dato o ingreso un dato no valido.");
                    Console.ReadKey();
                }
                Console.ReadKey();
            }
            


        }
    }
}
